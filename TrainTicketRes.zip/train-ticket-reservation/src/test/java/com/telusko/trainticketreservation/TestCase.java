package com.telusko.trainticketreservation;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import com.telusko.trainticketreservation.model.train;
import com.telusko.trainticketreservation.repository.trainRepository;
import com.telusko.trainticketreservation.service.TrainService;

//@RunWith(MockitoJUnitRunner.class)
@DataJpaTest
@SpringBootTest
public class TestCase {

	@InjectMocks
	public TrainService testTrain;

	@Mock
	public trainRepository repository;

	public train tr;

	@Before
	public void init() {

		MockitoAnnotations.initMocks(this);

		tr = new train(6780, "Shatabdi Express", "Ghaziabad", "Pune", 251);
	}

	@Test
	public void saveTrain() {
		assertEquals(6780, testTrain.saveTrai(tr));
	}

	@Test
	public void testGetTrain() {
		assertEquals(4, testTrain.getTrains().size());
	}

	@Test
	public void testGetTrainById() {
		assertEquals(tr.getClass(), testTrain.getTrain(6780).getClass());
	}

	@Test
	public void testDeleteTrain() {
		assertEquals(6780, 6780);
	}
}
