package com.telusko.trainticketreservation.exception;

public class TrainException extends Exception {

	private static final long serialVersionUID = 1L;

	public TrainException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
